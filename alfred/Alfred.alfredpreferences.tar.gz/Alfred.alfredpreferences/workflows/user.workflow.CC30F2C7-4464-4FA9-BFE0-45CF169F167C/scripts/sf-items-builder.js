#!/usr/bin/env osascript -l JavaScript

"use strict";

const getEnvVar = (varName) =>
	$.NSProcessInfo.processInfo.environment.objectForKey(varName).js;

const fisherYates = (array) => {
	let count = array.length;
	while (count) {
		const randomIndex = (Math.random() * count--) | 0;
		const temp = array[count];
		array[count] = array[randomIndex];
		array[randomIndex] = temp;
	}
};

const glFetchLinks = ({ filterFor, filterArg }) => {
	const results = [];
	const requestPageLimit = 1000;
	let requestOffset = 0;
	let hasMoreResults;

	const filterParamsMap = {
		"links-all": [`search=${encodeURI(filterArg)}`],
		"links-unread": [`search=${encodeURI(filterArg)}`, "read=false"],
		"links-starred": [`search=${encodeURI(filterArg)}`, "starred=true"],
		"links-with-tag": [
			`tag=${getEnvVar("search_tag")}`,
			`search=${encodeURI(filterArg)}`,
		],
		"links-random-unread": ["read=false"],
	};

	const filterParams = filterParamsMap[filterFor];

	do {
		const pageParams = [`limit=${requestPageLimit}`, `offset=${requestOffset}`];

		try {
			const responseJSON = app.doShellScript(
				`curl -G "${glAPIBaseURL}/links?${[...filterParams, ...pageParams].join("&")}" -H "${glAuthHeader}"`,
			);
			requestOffset += requestPageLimit;
			const response = JSON.parse(responseJSON);
			results.push(...response.data);
			hasMoreResults = response.hasMore;
		} catch (error) {
			console.log(error);
		}
	} while (hasMoreResults);

	return results;
};

const app = Application.currentApplication();
app.includeStandardAdditions = true;

const glAPIBaseURL = `${getEnvVar("gl_api_address")}/api/v1`;
const glAPIToken = getEnvVar("gl_api_token");
const glAuthHeader = `authorization: Bearer ${glAPIToken}`;

function run(argv) {
	const filterFor = argv[0];
	const filterArg = argv[1];

	const defaultSearchSubtitle = getEnvVar("default_search_subtitle");
	let rerunVal = 0.25;
	let items;

	const glApp = Application("GoodLinks");
	if (!glApp.running()) {
		app.doShellScript(`open -gj -a 'GoodLinks'`);
		return JSON.stringify({
			rerun: 0.1,
			items: [
				{
					title: "Launching GoodLinks",
					subtitle: "GoodLinks needs to be running to use this workflow",
				},
			],
		});
	}

	if (filterFor === "tags") {
		const allGLTags = JSON.parse(
			app.doShellScript(`curl -G "${glAPIBaseURL}/tags" -H "${glAuthHeader}"`),
		);
		const allGLTagsProps = allGLTags.map((t) => {
			const linksWithTagJSON = app.doShellScript(
				`curl -G "${glAPIBaseURL}/lists/all?tag=${t}" -H "${glAuthHeader}"`,
			);
			const linksWithTag = JSON.parse(linksWithTagJSON).data;
			return {
				name: t,
				tagged_links_count: linksWithTag.length,
			};
		});

		items = allGLTagsProps.map((tag) => {
			return {
				uid: tag.id,
				title: tag.name,
				subtitle: `${tag.tagged_links_count} link${
					tag.tagged_links_count > 1 ? "s" : ""
				}`,
				arg: "",
				variables: {
					search_tag: tag.name,
				},
				text: {
					largetype: tag.name,
				},
				quicklookurl: null,
			};
		});
	} else {
		const linkResults = glFetchLinks({ filterFor, filterArg });

		items = linkResults.map((link) => {
			const starredText = link.starred ? "\u2605" : "\u2606";
			const readText = link.readAt ? "read" : "unread";
			const tagInfo = link?.tags?.length
				? `tags: ${link.tags.join(", ")}`
				: "untagged";
			const linkInfoSubtitle = `${starredText} | ${readText} | ${tagInfo}`;
			const summaryText = link.summary || "(No summary available)";
			return {
				uid: link.uid,
				title: link.title,
				subtitle:
					defaultSearchSubtitle === "show summary"
						? summaryText
						: linkInfoSubtitle,
				arg: link.url,
				mods: {
					cmd: {
						valid: true,
						subtitle:
							defaultSearchSubtitle === "show summary"
								? linkInfoSubtitle
								: summaryText,
					},
					alt: {
						valid: true,
						subtitle: "Copy the URL to the clipboard",
						arg: link.url,
						variables: {
							action: "copy",
						},
					},
					ctrl: {
						valid: true,
						subtitle: link.url,
					},
				},
				text: {
					copy: link.url,
					largetype: `${link.title}\n\n${summaryText}`,
				},
				quicklookurl: null,
			};
		});

		if (filterFor === "links-random-unread") {
			rerunVal = 0;
			fisherYates(items); // randomize array
			items = items.slice(0, 1);
			items.push({
				title: "Get another…",
				subtitle: "Search for another random link",
				arg: "trigger:self_random_unread",
				icon: {
					path: "./icons/sf-symbols-red-arrow.clockwise.circle.fill.png",
				},
			});
		}
	}

	if (!items.length) {
		items.push({
			title: "No results",
			subtitle: "GoodLinks has no matching items",
		});
	}

	const scriptFilterItems = {
		rerun: rerunVal,
		...{ items },
	};

	const scriptFilterItemsJSON = JSON.stringify(scriptFilterItems);

	return scriptFilterItemsJSON;
}
