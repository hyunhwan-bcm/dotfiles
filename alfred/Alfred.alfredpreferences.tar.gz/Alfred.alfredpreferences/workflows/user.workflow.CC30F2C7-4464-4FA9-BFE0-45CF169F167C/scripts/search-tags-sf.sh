#!/bin/zsh --no-rcs

script_filter_items_json=$(osascript -l JavaScript ./scripts/sf-items-builder.js tags '')

printf '%s' "$script_filter_items_json"
