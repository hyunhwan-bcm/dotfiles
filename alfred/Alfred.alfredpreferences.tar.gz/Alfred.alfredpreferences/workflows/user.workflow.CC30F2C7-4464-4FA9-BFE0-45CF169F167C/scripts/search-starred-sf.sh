#!/bin/zsh --no-rcs

script_filter_items_json=$(osascript -l JavaScript ./scripts/sf-items-builder.js links-starred "$1")

printf '%s' "$script_filter_items_json"
